<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Rathi
 */

?>


<footer class="footer-main">
		<div class="footer-sec">
			<div class="container">
				<div class="footer-div">
					<div class="footer-logo">
						<?php dynamic_sidebar( 'footer-0' ); ?>
					</div>
					<div class="footer-cat">
						<?php dynamic_sidebar( 'footer-1' ); ?>
					</div>
					<div class="useful-links">
						<?php dynamic_sidebar( 'footer-2' ); ?>
					</div>
					<div class="contact-details-footer">
						<?php dynamic_sidebar( 'footer-3' ); ?>
					</div>
				</div>
			</div>
		</div>
		<div class="bottom-footer-one">
			<div class="container">
                <div class="second-footer-row">
                    <div class="brand-logo-sec">
                        <?php dynamic_sidebar( 'footer-4' ); ?>
                    </div>
                    <div class="social-icon-sec">
                        <?php dynamic_sidebar( 'footer-5' ); ?>
                    </div>
                </div>
			</div>
		</div>
        <div class="bottom-footer-two">
			<div class="container">
				<?php dynamic_sidebar( 'footer-6' ); ?>
			</div>
		</div>
		<div class="scroll-top">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/scroll-icon.png">
		</div>
</footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>


